df -h | grep "fuse" -o
