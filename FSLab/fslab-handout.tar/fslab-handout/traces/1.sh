cd mnt
mkdir dir1
mkdir dir2
ls
cd dir2
mkdir dir3
ls
