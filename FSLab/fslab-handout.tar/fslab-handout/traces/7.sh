cd mnt
mkdir dir1
cd dir1
mkdir dir2
touch file1
ls
mv file1 file2
ls
mv dir2 dir3
ls
cd ..
mv dir1 dir
ls
cd dir
ls

