cd mnt
echo 12345 > file1
more file1
echo 23333333333 > file1
more file1
echo abcdefg >> file1
more file1
